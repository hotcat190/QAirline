CREATE DATABASE  IF NOT EXISTS `test` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `test`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: gateway01.ap-southeast-1.prod.aws.tidbcloud.com    Database: test
-- ------------------------------------------------------
-- Server version	5.7.28-TiDB-Serverless

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `airport`
--

DROP TABLE IF EXISTS `airport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `airport` (
  `idairport` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `country` varchar(45) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `city` varchar(45) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `code` varchar(45) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`idairport`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `idairport_UNIQUE` (`idairport`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci AUTO_INCREMENT=120001;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `airport`
--

LOCK TABLES `airport` WRITE;
/*!40000 ALTER TABLE `airport` DISABLE KEYS */;
INSERT INTO `airport` VALUES (1,'Tan Son Nhat International Airport','Vietnam','Ho Chi Minh City','SGN'),(2,'Noi Bai International Airport','Vietnam','Hanoi','HAN'),(3,'Da Nang International Airport','Vietnam','Da Nang','DAD'),(4,'Cam Ranh International Airport','Vietnam','Nha Trang','CXR'),(5,'Changi Airport','Singapore','Singapore','SIN'),(6,'Incheon International Airport','South Korea','Incheon','ICN'),(7,'Seoul Gimpo International Airport','South Korea','Seoul','GMP'),(8,'Kuala Lumpur International Airport','Malaysia','Kuala Lumpur','KUL'),(9,'Hong Kong International Airport','Hong Kong','Hong Kong','HKG'),(10,'Suvarnabhumi Airport','Thailand','Bangkok','BKK'),(11,'Narita International Airport','Japan','Tokyo','NRT'),(12,'Tokyo Haneda Airport','Japan','Tokyo','HND'),(13,'Los Angeles International Airport','United States','Los Angeles','LAX'),(14,'John F. Kennedy International Airport','United States','New York','JFK'),(15,'Heathrow Airport','United Kingdom','London','LHR'),(16,'Charles de Gaulle Airport','France','Paris','CDG'),(17,'Amsterdam Schiphol Airport','Netherlands','Amsterdam','AMS'),(18,'Berlin Brandenburg Airport','Germany','Berlin','BER'),(19,'Dubai International Airport','United Arab Emirates','Dubai','DXB'),(20,'Hamad International Airport','Qatar','Doha','DOH'),(21,'San Francisco International Airport','United States','San Francisco','SFO'),(22,'Miami International Airport','United States','Miami','MIA'),(23,'Sydney Kingsford Smith Airport','Australia','Sydney','SYD'),(24,'Auckland Airport','New Zealand','Auckland','AKL'),(25,'Manchester Airport','United Kingdom','Manchester','MAN'),(26,'Zurich Airport','Switzerland','Zurich','ZRH'),(27,'Vienna International Airport','Austria','Vienna','VIE'),(28,'Copenhagen Airport','Denmark','Copenhagen','CPH'),(29,'Brussels Airport','Belgium','Brussels','BRU'),(30,'Oslo Gardermoen Airport','Norway','Oslo','OSL'),(31,'Stockholm Arlanda Airport','Sweden','Stockholm','ARN'),(32,'Lisbon Portela Airport','Portugal','Lisbon','LIS'),(33,'Madrid Barajas Airport','Spain','Madrid','MAD'),(34,'Rome Fiumicino Airport','Italy','Rome','FCO'),(35,'Istanbul Airport','Turkey','Istanbul','IST'),(36,'Athens International Airport','Greece','Athens','ATH'),(37,'Cairo International Airport','Egypt','Cairo','CAI'),(38,'Cape Town International Airport','South Africa','Cape Town','CPT'),(39,'Rio de Janeiro International Airport','Brazil','Rio de Janeiro','GIG'),(40,'Sao Paulo/Guarulhos International Airport','Brazil','Sao Paulo','GRU'),(41,'Cat Bi International Airport','Vietnam','Hai Phong','HPH'),(42,'Can Tho International Airport','Vietnam','Can Tho','VCA'),(43,'Phu Quoc International Airport','Vietnam','Phu Quoc','PQC'),(44,'Van Don International Airport','Vietnam','Quang Ninh','VDO'),(45,'Thoi Loi Airport','Vietnam','Ho Chi Minh City','VVH'),(46,'Bai Thuong International Airport','Vietnam','Nha Trang','CXR'),(47,'Quang Binh Airport','Vietnam','Dong Hoi','UIH'),(48,'Hue Phu Bai International Airport','Vietnam','Hue','HUI'),(49,'Dong Hoi Airport','Vietnam','Quang Binh','UIH'),(50,'Pleiku Airport','Vietnam','Gia Lai','PXU'),(51,'Rach Gia Airport','Vietnam','Kien Giang','VKG'),(52,'Buon Ma Thuot Airport','Vietnam','Dak Lak','BMV'),(53,'Chu Lai Airport','Vietnam','Quang Nam','VCL');
/*!40000 ALTER TABLE `airport` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-21 17:38:47
