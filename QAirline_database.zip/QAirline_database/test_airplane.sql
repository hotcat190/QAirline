CREATE DATABASE  IF NOT EXISTS `test` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `test`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: gateway01.ap-southeast-1.prod.aws.tidbcloud.com    Database: test
-- ------------------------------------------------------
-- Server version	5.7.28-TiDB-Serverless

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `airplane`
--

DROP TABLE IF EXISTS `airplane`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `airplane` (
  `idAirplane` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `type` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `capacity` int(10) unsigned NOT NULL,
  `status` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`idAirplane`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci AUTO_INCREMENT=120001;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `airplane`
--

LOCK TABLES `airplane` WRITE;
/*!40000 ALTER TABLE `airplane` DISABLE KEYS */;
INSERT INTO `airplane` VALUES (1,'AB123','Boeing 737',180,'Active'),(2,'CD456','Airbus A320',150,'Maintenance'),(3,'EF789','Boeing 787',330,'Active'),(4,'GH012','Boeing 737',180,'Active'),(5,'IJ345','Airbus A320',150,'Maintenance'),(6,'KL678','Boeing 787',330,'Active'),(7,'MN012','Boeing 737',180,'Active'),(8,'OP345','Airbus A320',150,'Maintenance'),(9,'QR678','Boeing 787',330,'Active'),(10,'ST012','Boeing 737',180,'Active'),(11,'UV345','Airbus A320',150,'Maintenance'),(12,'WX678','Boeing 787',330,'Active'),(13,'YZ012','Boeing 737',180,'Active'),(14,'AB123','Airbus A320',150,'Maintenance'),(15,'CD456','Boeing 787',330,'Active'),(16,'EF789','Boeing 737',180,'Active'),(17,'GH013','Boeing 737',180,'Active'),(18,'IJ346','Airbus A320',150,'Maintenance'),(19,'KL679','Boeing 787',330,'Active'),(20,'MN013','Boeing 737',180,'Active'),(21,'OP346','Airbus A320',150,'Maintenance'),(22,'QR679','Boeing 787',330,'Active'),(23,'ST013','Boeing 737',180,'Active'),(24,'UV346','Airbus A320',150,'Maintenance'),(25,'WX679','Boeing 787',330,'Active'),(26,'YZ013','Boeing 737',180,'Active'),(27,'AB124','Airbus A320',150,'Retired'),(28,'CD457','Boeing 787',330,'Active'),(29,'EF790','Boeing 737',180,'Active'),(30,'GH014','Boeing 737',180,'Active'),(31,'IJ347','Airbus A320',150,'Maintenance'),(32,'KL680','Boeing 787',330,'Active'),(33,'MN014','Boeing 737',180,'Active'),(34,'OP347','Airbus A320',150,'Maintenance'),(35,'QR680','Boeing 787',330,'Active'),(36,'ST014','Boeing 737',180,'Active'),(37,'UV347','Airbus A320',150,'Maintenance'),(38,'WX680','Boeing 787',330,'Active'),(39,'YZ014','Boeing 737',180,'Active'),(40,'AB125','Airbus A320',150,'Maintenance'),(41,'CD458','Boeing 787',330,'Active'),(42,'EF791','Boeing 737',180,'Active'),(43,'GH015','Boeing 737',180,'Active'),(44,'IJ348','Airbus A320',150,'Maintenance'),(45,'KL681','Boeing 787',330,'Active'),(46,'MN015','Boeing 737',180,'Active'),(47,'OP348','Airbus A320',150,'Maintenance'),(48,'QR681','Boeing 787',330,'Active'),(49,'ST015','Boeing 737',180,'Active'),(50,'UV348','Airbus A320',150,'Maintenance'),(51,'WX681','Boeing 787',330,'Active'),(52,'YZ015','Boeing 737',180,'Active'),(53,'AB126','Airbus A320',150,'Maintenance'),(54,'CD459','Boeing 787',330,'Active'),(55,'EF792','Boeing 737',180,'Active'),(56,'GH016','Boeing 737',180,'Active'),(57,'IJ349','Airbus A320',150,'Maintenance'),(58,'KL682','Boeing 787',330,'Active'),(59,'MN016','Boeing 737',180,'Active'),(60,'OP349','Airbus A320',150,'Maintenance'),(61,'QR682','Boeing 787',330,'Active'),(62,'ST016','Boeing 737',180,'Active'),(63,'UV349','Airbus A320',150,'Maintenance'),(64,'WX682','Boeing 787',330,'Active'),(65,'YZ016','Boeing 737',180,'Active'),(66,'AB127','Airbus A320',150,'Maintenance'),(67,'CD460','Boeing 787',330,'Active'),(68,'EF793','Boeing 737',180,'Active'),(69,'GH017','Boeing 737',180,'Active'),(70,'IJ350','Airbus A320',150,'Maintenance'),(71,'KL683','Boeing 787',330,'Active'),(72,'MN017','Boeing 737',180,'Active'),(73,'OP350','Airbus A320',150,'Maintenance'),(74,'QR683','Boeing 787',330,'Active'),(75,'ST017','Boeing 737',180,'Active'),(76,'UV350','Airbus A320',150,'Maintenance'),(77,'WX683','Boeing 787',330,'Active'),(78,'YZ017','Boeing 737',180,'Active'),(79,'AB128','Airbus A320',150,'Maintenance'),(80,'CD461','Boeing 787',330,'Active'),(81,'EF794','Boeing 737',180,'Active'),(82,'GH018','Boeing 737',180,'Active'),(83,'IJ351','Airbus A320',150,'Maintenance'),(84,'KL684','Boeing 787',330,'Active'),(85,'MN018','Boeing 737',180,'Active'),(86,'OP351','Airbus A320',150,'Maintenance'),(87,'QR684','Boeing 787',330,'Active'),(88,'ST018','Boeing 737',180,'Active'),(89,'UV351','Airbus A320',150,'Maintenance'),(90,'WX684','Boeing 787',330,'Active'),(91,'YZ018','Boeing 737',180,'Active'),(92,'AB129','Airbus A320',150,'Maintenance'),(93,'CD462','Boeing 787',330,'Active'),(94,'EF795','Boeing 737',180,'Active'),(95,'GH019','Boeing 737',180,'Active'),(96,'IJ352','Airbus A320',150,'Maintenance'),(97,'KL685','Boeing 787',330,'Active'),(98,'MN019','Boeing 737',180,'Active'),(99,'OP352','Airbus A320',150,'Maintenance'),(100,'QR685','Boeing 787',330,'Active'),(60002,'OS727','Boeing 727',726,'Active'),(60003,'CK800','Airbus 800',800,'Maintenance'),(60004,'CK801','Airbus 800',800,'Active'),(60005,'QA101','Boeing 737',101,'Retired'),(60008,'QA103','Boeing 727',103,'Active'),(90001,'QA100','Boeing 737',180,'Active');
/*!40000 ALTER TABLE `airplane` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-21 17:38:58
