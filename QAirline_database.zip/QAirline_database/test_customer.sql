CREATE DATABASE  IF NOT EXISTS `test` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `test`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: gateway01.ap-southeast-1.prod.aws.tidbcloud.com    Database: test
-- ------------------------------------------------------
-- Server version	5.7.28-TiDB-Serverless

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `idCustomer` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(16) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `password` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `numberPhone` varchar(11) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`idCustomer`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `id_UNIQUE` (`idCustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci AUTO_INCREMENT=360001;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'nguyenphuc','phuc.nguyen@qairline.com','password123','0901234567'),(2,'lethithanh','thanh.le@qairline.com','password456','0902345678'),(3,'phamvanminh','minh.pham@qairline.com','password789','0903456789'),(4,'tranthihuyen','huyen.tran@qairline.com','password101','0904567890'),(5,'dluong','test@gmail.com','$argon2id$v=19$m=65536,t=3,p=4$Psjn0bOW7iGFLxyRJUM5Vg$UfCXh1xvYtg1Bz7oWzOiNbu7JmgTgaMBMk5kMIFjZXc','0987654321'),(30001,'hotcat190','hotcat190@gmail.com','$argon2id$v=19$m=65536,t=3,p=4$9wh7KOlLC9CJuHNnlivftQ$JxxN2tE3qJATPZFCpFp5ZHyi0FBy7/s4MHf9dZMD20c',''),(60001,'hotcat190','091tactoh@gmail.com','$argon2id$v=19$m=65536,t=3,p=4$AHpsVZdJjK8pjXGPeq6NFA$RKKr9P9ubn1tSvZAcAQeElOp5QYpUcNbRWCcm6g4oa4',''),(90001,'name123','test@mail.abc','$argon2id$v=19$m=65536,t=3,p=4$p69/+UXnz+H9i6eZcFbVJw$Pr80z46Qkw42hUO3y1RBXVqUrJwXH0ijCnIeeXmLKwY',''),(120001,'testuser1','testuser1@gmail.com','$argon2id$v=19$m=65536,t=3,p=4$rEddIBOkfQG7txvV+3cRyQ$z9UC/FB3Aj060gBnsyU4lr5bbv2fuqPYoMPAzfF/nws',''),(150001,'dluong','test3@gmail.com','$argon2id$v=19$m=65536,t=3,p=4$RgVpRbn9oyTryr9TV/UkJw$bWb6zxY7ktrnh1jJmtsPQr5Q062jsQpci0Ue4SegZtQ','0987654321'),(150002,'dluong','test4@gmail.com','$argon2id$v=19$m=65536,t=3,p=4$JvP16kEB1bUCIqS9qJ9mbw$UbG9U4b+AxWIn9E3OYzCKi+rVNssM9E8zcPSk/9qXaQ',NULL),(180001,'Le Hoang Vu','vu@gmail.com','$argon2id$v=19$m=65536,t=3,p=4$VWNO8ZkCkZYm8eA6FAATZQ$LRDFFgoE6DWZke35oBGTaL8GJM1jpBJDJY/K4TZ1Qj0',''),(180002,'Le Hoang Vu','vuvu@gmail.com','$argon2id$v=19$m=65536,t=3,p=4$S3GvDwRGfbgSN0W3vW/Uyg$amCQZ0/oBmy+GxBlctT8xHNMaYAhv68juZczY45JS90',''),(180003,'le hoang vu','giau@gmail.com','$argon2id$v=19$m=65536,t=3,p=4$UQzYLMMK0+/x/QHeGtRGJQ$GWLUAm9afYKCa2/G673jx1CdQK/jkE0siv23mHN67Y8',''),(210001,'Hoang Vu Samson','giauvu@gmail.com','$argon2id$v=19$m=65536,t=3,p=4$pZfWKvvbKF0jJCd/WYkK+w$P233M3gOxEifIy9hOJQtZjK5D9SEh4pTbGMxYMqRvKk',''),(240001,'lehoangvu','vuniem@gmail.com','$argon2id$v=19$m=65536,t=3,p=4$+II/CVLOajcjk22sJF0mWw$rpa681nNRuFmefr0TtXxXKsML5vEzcd8PHsIrLdnnGQ',''),(270001,'Ngoc Giau','giauu@gmail.com','$argon2id$v=19$m=65536,t=3,p=4$zzb8ffTkVlI7a4EI7x5SnA$ToygTVlaQZCEMGqkXECflXiHIWHwVR9w54rN6Fhfyq0',''),(300001,'Le Hoang Long','long@gmail.com','$argon2id$v=19$m=65536,t=3,p=4$Q/ys0iqMJD/H/Po0pa6k1Q$Sl9enhMFveKS8G3xWFf9Ymw2+2m2mAvrV/CA2O8Rxu4',''),(330001,'Le Hoang Vu','vune@gmail.com','$argon2id$v=19$m=65536,t=3,p=4$yF644OiRAqElRqOlExiqvA$UVJWCAzrVdFpflbWE4Qhhc/IOAJAbNo6GFc7cKXVHp4',''),(330002,'Le Hoang Vu','vuniem131104@gmail.com','$argon2id$v=19$m=65536,t=3,p=4$DtY0sotzgYhydD2Y6JwudQ$UavBeX6iJvTeu5HhPzj5ZJW25MVqijVy4qcU15VETDk',''),(330003,'Le Hoang Vu','vuniemm@gmail.com','$argon2id$v=19$m=65536,t=3,p=4$Hg8E3uTWVOcQWY6iNTf8kw$M0fmUt3n+mha+UJ98MDTDLAtd97KbdJUeHMTzZX/8PA',''),(330004,'Le Hoang Vu','vu131104@gmail.com','$argon2id$v=19$m=65536,t=3,p=4$tzV4ERh/r6XVfjRQ/b6mcA$v7+17TW9+LLeXdjm2HH36s38bSd/iDoQ/r3tyMh8aTY',''),(330005,'Le Hoang Vu','vuhoa@gmail.com','$argon2id$v=19$m=65536,t=3,p=4$8hA9wl99Ou0PoK+9eRyg6w$ZFiLMOkK59S/EhCOWmWALDJ/ejGgvAJGqXNeLjUFhG0','');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-21 17:39:03
